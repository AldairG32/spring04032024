package com.appwithspring.demo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
